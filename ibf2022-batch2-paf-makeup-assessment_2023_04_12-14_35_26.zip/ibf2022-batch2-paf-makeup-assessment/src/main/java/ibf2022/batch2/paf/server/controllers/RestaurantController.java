package ibf2022.batch2.paf.server.controllers;

public class RestaurantController {

	// TODO: Task 2 - request handler
	

	// TODO: Task 3 - request handler


	// TODO: Task 4 - request handler
	

	// TODO: Task 5 - request handler

}
