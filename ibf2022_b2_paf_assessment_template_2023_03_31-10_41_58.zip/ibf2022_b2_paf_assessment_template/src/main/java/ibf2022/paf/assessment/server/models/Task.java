package ibf2022.paf.assessment.server.models;

// TODO: Task 4

public class Task {
}
