package ibf2022.paf.assessment.server.repositories;

// TODO: Task 6

public class TaskRepository {
}
