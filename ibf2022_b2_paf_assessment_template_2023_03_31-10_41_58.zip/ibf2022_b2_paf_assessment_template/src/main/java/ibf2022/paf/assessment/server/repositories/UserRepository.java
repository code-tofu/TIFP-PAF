package ibf2022.paf.assessment.server.repositories;

// TODO: Task 3

public class UserRepository {
}
