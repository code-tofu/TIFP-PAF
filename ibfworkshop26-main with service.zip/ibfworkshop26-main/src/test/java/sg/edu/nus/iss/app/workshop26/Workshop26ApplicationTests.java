package sg.edu.nus.iss.app.workshop26;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workshop26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
