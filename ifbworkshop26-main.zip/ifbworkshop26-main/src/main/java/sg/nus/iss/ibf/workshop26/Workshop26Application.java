package sg.nus.iss.ibf.workshop26;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Workshop26Application {

	public static void main(String[] args) {
		SpringApplication.run(Workshop26Application.class, args);
	}

}
