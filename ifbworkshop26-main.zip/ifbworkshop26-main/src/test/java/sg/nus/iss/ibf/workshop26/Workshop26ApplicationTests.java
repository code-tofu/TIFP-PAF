package sg.nus.iss.ibf.workshop26;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workshop26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
